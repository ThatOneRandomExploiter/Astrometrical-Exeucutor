﻿using System;
using CloudyApi;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Astrometrical
{
    public partial class Astrometrical : Form
    {
        public Astrometrical()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            label1.Text = "Injected: False";
            label2.Text = "Hello, From Astrometrical Executor";
        }

        private void Execute_Click(object sender, EventArgs e)
        {
            CloudyApi.Api.execute(richTextBox1.Text);
        }

        private void Clear_Click(object sender, EventArgs e)
        {
            richTextBox1.Text = "-- Join https://discord.gg/qu7dyqBT";
        }

        private void Closeroblox_Click(object sender, EventArgs e)
        {
            CloudyApi.Api.killRoblox();
        }

        private void Inject_Click(object sender, EventArgs e)
        {
            CloudyApi.Api.inject();
            label1.Text = "Injected: True";
            richTextBox1.Text = "print('Join https://discord.gg/qu7dyqBT Today')";
            CloudyApi.Api.execute(richTextBox1.Text);
            richTextBox1.Text = "loadstring(game:HttpGet('https://raw.githubusercontent.com/unified-naming-convention/NamingStandard/refs/heads/main/UNCCheckEnv.lua'))()";
            CloudyApi.Api.execute(richTextBox1.Text);
            richTextBox1.Text = "-- Join https://discord.gg/qu7dyqBT";
        }

        private void scripthub_Click(object sender, EventArgs e)
        {
            richTextBox1.Text = "loadstring(game:HttpGet('https://https://pastebin.com/raw/wh5dmtBy'))()";
            CloudyApi.Api.execute(richTextBox1.Text);
            richTextBox1.Text = "-- Join https://discord.gg/qu7dyqBT";

        }

    }
}
